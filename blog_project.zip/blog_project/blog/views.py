from django.shortcuts import render
from django.http import HttpResponse
from .models import Post
from datetime import datetime

def home(request):
    posts = Post.objects.all()
    return render(request, 'blog/home.html', {'posts': posts})

def show_posts(request):
    posts = Post.objects.all()
    return render(request, 'blog/show_posts.html', {'posts': posts})

def add_post(request):
    return render(request, 'blog/add_post.html')

def add(request):
    p_title = request.POST.get("t1")
    p_content = request.POST.get("t2")
    count = Post.objects.all().filter(title__iexact=p_title).count()
    if count == 0:
        Post.objects.create(title=p_title,content=p_content,created_at=datetime.now(),updated_at=datetime.now())
        posts = Post.objects.all()
        return render(request, 'blog/show_posts.html', {'posts': posts})
    return render(request, 'blog/home.html')

def delete_post(request):
    p_title = request.GET["p_title"]
    Post.objects.all().filter(title=p_title).delete()
    posts = Post.objects.all()
    return render(request, 'blog/show_posts.html', {'posts': posts})
    