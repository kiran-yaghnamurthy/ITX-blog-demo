from django.urls import path
from blog import views

urlpatterns = [
    path('show_posts/',views.show_posts),
    path('home/', views.home, name='blog-home'),
    path('add_post/',views.add_post),
    path('add/',views.add),
    path('delete_post/',views.delete_post)
]
